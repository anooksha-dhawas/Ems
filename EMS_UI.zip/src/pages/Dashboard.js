import React from 'react';

function Dashboard() {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Welcome to the Dashboard</h2>
      <p>This is a basic UI. Add employee and view data functionalities here.</p>
    </div>
  );
}

export default Dashboard;