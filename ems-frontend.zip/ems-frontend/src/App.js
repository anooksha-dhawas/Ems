import React, { useState } from 'react';
import LoginForm from './components/LoginForm';
import Dashboard from './components/Dashboard';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem('token'));

  return (
    <div className="App">
      {isLoggedIn ? <Dashboard /> : <LoginForm onLogin={() => setIsLoggedIn(true)} />}
    </div>
  );
}

export default App;