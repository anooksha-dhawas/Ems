import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:8080' });

export const login = (credentials) => API.post('/auth/login', credentials);
export const getEmployees = () => API.get('/employees');
export const createEmployee = (employee) => API.post('/employees', employee);

export default API;