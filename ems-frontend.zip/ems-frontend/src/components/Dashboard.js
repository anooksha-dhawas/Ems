import React from 'react';
import EmployeeList from './EmployeeList';
import AddEmployeeForm from './AddEmployeeForm';

const Dashboard = () => {
  return (
    <div>
      <h2>Admin Dashboard</h2>
      <AddEmployeeForm />
      <EmployeeList />
    </div>
  );
};

export default Dashboard;