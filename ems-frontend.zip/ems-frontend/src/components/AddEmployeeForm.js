import React, { useState } from 'react';
import { createEmployee } from '../services/api';

const AddEmployeeForm = () => {
  const [formData, setFormData] = useState({ name: '', department: '' });

  const handleSubmit = () => {
    createEmployee(formData).then(() => alert('Employee added!'));
  };

  return (
    <div>
      <h3>Add Employee</h3>
      <input placeholder="Name" onChange={e => setFormData({ ...formData, name: e.target.value })} />
      <input placeholder="Department" onChange={e => setFormData({ ...formData, department: e.target.value })} />
      <button onClick={handleSubmit}>Add</button>
    </div>
  );
};

export default AddEmployeeForm;